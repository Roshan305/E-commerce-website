<?php
class Log {
    
    function Log($file_path) {
    }
        
    function message($message) {
    }
}
?>